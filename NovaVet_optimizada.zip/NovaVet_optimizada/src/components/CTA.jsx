import content from "../config/content";

export default function CTA() {
  const href = `https://wa.me/${content.company.phone}?text=${encodeURIComponent(
    content.contact.whatsappMessage
  )}`;

  return (
    <section className="section">
      <div className="container cta cta-light">
        <div>
          <span className="eyebrow">Agende hoje</span>

          <h2>Cuide da saúde do seu pet com quem entende.</h2>

          <p>
            Fale com a NovaVet pelo WhatsApp e agende uma consulta de forma rápida.
          </p>
        </div>

        <a
          className="button button-primary"
          href={href}
          target="_blank"
          rel="noreferrer"
        >
          Agendar consulta →
        </a>
      </div>
    </section>
  );
}
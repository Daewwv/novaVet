import team from "../config/team";

export default function Team() {
  return (
    <section className="section">
      <div className="container">
        <div className="section-heading">
          <span className="eyebrow">Nossa equipe</span>

          <h2>Veterinários apaixonados pelo cuidado animal.</h2>

          <p>
            Profissionais preparados para oferecer atendimento humanizado e
            medicina veterinária moderna.
          </p>
        </div>

        <div className="team-grid">
          {team.map((vet) => (
            <article className="team-card" key={vet.name}>
              <img src={vet.image} alt={`${vet.name} - ${vet.role}`} />

              <div className="team-card-content">
                <h3>{vet.name}</h3>
                <strong>{vet.role}</strong>
                <p>{vet.specialty}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
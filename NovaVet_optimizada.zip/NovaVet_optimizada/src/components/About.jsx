export default function About({ site }) {
  return (
    <section className="section" id="sobre">
      <div className="container split">
        <div>
          <span className="eyebrow">Por que escolher a NovaVet</span>
          <h2>{site.about.title}</h2>
          <p>{site.about.text}</p>

          <div className="about-list">
            <div>✓ Equipe especializada</div>
            <div>✓ Atendimento humanizado</div>
            <div>✓ Estrutura moderna</div>
            <div>✓ Diagnóstico completo</div>
            <div>✓ Emergência 24 horas</div>
            <div>✓ Orientação aos tutores</div>
          </div>
        </div>

        <div className="about-image">
          <img
            src="https://images.unsplash.com/photo-1576201836106-db1758fd1c97?auto=format&fit=crop&w=1200&q=85"
            alt="Veterinária atendendo um animal"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  );
}

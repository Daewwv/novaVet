import content from "../config/content";

export default function FloatingWhatsApp() {
  const href = `https://wa.me/${content.company.phone}?text=${encodeURIComponent(
    content.contact.whatsappMessage
  )}`;

  return (
    <a
      href={href}
      className="floating-whatsapp"
      target="_blank"
      rel="noreferrer"
      aria-label="WhatsApp"
    >
      💬
    </a>
  );
}
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header({ site }) {
  const [open, setOpen] = useState(false);
  const closeMenu = () => setOpen(false);

  return (
    <header className="site-header">
      <div className="container header-inner">
        <a className="brand" href="#inicio" onClick={closeMenu}>
          <span className="brand-mark">N</span>
          <span>{site.company.name}</span>
        </a>

        <button
          className="menu-toggle"
          type="button"
          onClick={() => setOpen((current) => !current)}
          aria-expanded={open}
          aria-controls="main-navigation"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>

        <nav id="main-navigation" className={open ? "nav open" : "nav"}>
          <a href="#inicio" onClick={closeMenu}>Início</a>
          <a href="#servicos" onClick={closeMenu}>Serviços</a>
          <a href="#sobre" onClick={closeMenu}>Sobre</a>
          <a href="#faq" onClick={closeMenu}>FAQ</a>
          <a className="button button-primary" href="#contato" onClick={closeMenu}>
            Agendar consulta
          </a>
        </nav>
      </div>
    </header>
  );
}

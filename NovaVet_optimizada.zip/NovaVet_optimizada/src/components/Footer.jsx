import content from "../config/content";

export default function Footer() {
  const whatsappUrl = `https://wa.me/${content.company.phone}?text=${encodeURIComponent(
    content.contact.whatsappMessage
  )}`;

  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <h3>{content.company.name}</h3>
          <p>{content.company.description}</p>
        </div>

        <div>
          <h4>Contato</h4>
          <a href={`mailto:${content.company.email}`}>{content.company.email}</a>
          <p>{content.company.city}</p>
          <a href={whatsappUrl} target="_blank" rel="noreferrer">
            Falar no WhatsApp
          </a>
        </div>

        <div>
          <h4>Horários</h4>
          <p>Segunda a sexta: 08h às 19h</p>
          <p>Sábado: 08h às 14h</p>
          <p>Emergências: 24h</p>
        </div>

        <div>
          <h4>Links</h4>
          <a href="#servicos">Serviços</a>
          <a href="#sobre">Sobre</a>
          <a href="#faq">Perguntas frequentes</a>
        </div>
      </div>

      <div className="container footer-bottom">
        <p>© 2026 {content.company.name}. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}

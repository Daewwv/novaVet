import theme from "./theme";
import content from "./content";
import portfolio from "./portfolio";
import services from "./services";
import faq from "./faq";
import modules from "./modules";

const site = {
company: content.company,

  theme,

  hero: content.hero,

services,

portfolio,

  about: content.about,

  faq,

  contact: content.contact,

  modules
};

export default site;

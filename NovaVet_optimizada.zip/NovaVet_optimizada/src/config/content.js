const content = {
  company: {
    name: "NovaVet",
    tagline: "Cuidado veterinário com carinho e confiança",
    description:
      "Clínica veterinária moderna com atendimento humanizado para cães e gatos.",
    phone: "5541996123134",
    email: "contato@novavet.com.br",
    city: "Curitiba, PR"
  },

  hero: {
    eyebrow: "Clínica Veterinária",

    title: "Cuidamos da saúde de quem faz parte da sua família.",

    text:
      "Consultas, vacinas, exames, cirurgias e atendimento veterinário com carinho, segurança e tecnologia.",

    primaryCta: "Agendar consulta",

    secondaryCta: "Conhecer serviços",

    image:
      "https://images.unsplash.com/photo-1628009368231-7bb7cfcb0def?auto=format&fit=crop&w=1400&q=85",

    badge: {
      title: "Atendimento 24h",
      subtitle: "Emergências veterinárias"
    },

  
  },

  about: {
    title: "Atendimento veterinário completo e humanizado.",
    text:
      "Nossa equipe cuida de cada animal com atenção individual, estrutura moderna e orientação clara para os tutores."
  },

  contact: {
    title: "Seu pet merece o melhor cuidado.",

    text:
      "Fale conosco e agende uma consulta para seu cão ou gato.",

    whatsappMessage:
      "Olá! Gostaria de agendar uma consulta veterinária na NovaVet."
  }
};

export default content;
import Header from "./components/Header";
import Hero from "./components/Hero";
import Services from "./components/Services";
import About from "./components/About";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import Stats from "./components/Stats";
import Portfolio from "./components/Portfolio";
import Process from "./components/Process";
import Testimonials from "./components/Testimonials";
import CTA from "./components/CTA";
import Team from "./components/Team";
import FloatingWhatsApp from "./components/FloatingWhatsApp";
import Reveal from "./components/Reveal";
import site from "./config/site";

const Section = ({ enabled, children }) =>
  enabled ? <Reveal>{children}</Reveal> : null;

export default function App() {
  const { modules } = site;

  return (
    <>
      <Header site={site} />

      <main>
        <Hero site={site} />

        <Section enabled={modules.services}>
          <Services site={site} />
        </Section>

        <Section enabled={modules.about}>
          <About site={site} />
        </Section>

        <Section enabled={modules.stats}>
          <Stats />
        </Section>

        <Section enabled={modules.team}>
          <Team />
        </Section>

        <Section enabled={modules.portfolio}>
          <Portfolio site={site} />
        </Section>

        <Section enabled={modules.process}>
          <Process />
        </Section>

        <Section enabled={modules.testimonials}>
          <Testimonials />
        </Section>

        <Section enabled={modules.faq}>
          <FAQ site={site} />
        </Section>

        <Section enabled={modules.cta}>
          <CTA />
        </Section>

        <Section enabled={modules.contact}>
          <Contact site={site} />
        </Section>

        <FloatingWhatsApp />
      </main>

      <Footer />
    </>
  );
}
